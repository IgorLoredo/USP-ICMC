#include <stdlib.h>
#include <stdio.h>
#include <maze.h>
//#include "maze.h"

GRAFO *iniciarGrafo(float x,float y,int pos){
    GRAFO *new = (GRAFO*)calloc(1,sizeof(GRAFO));
    new->y = y;
    new->x = x;
    new->pos = pos;
    return new;
}

LAB *iniciar_lab(int n){
    LAB *new = (LAB*)calloc(1,sizeof(LAB));
    new->vet = (GRAFO**)malloc(sizeof(GRAFO*)*n);
    return new;
} 

int inseriCamara(LAB*p,int camara,int aberto){
    if(!p) return ERRO_LAB; 
    p->vet[camara]->aberto = aberto;
    return SUCESS;
}

int inseriSeg(LAB *lab, int c1, int c2){
    if(!lab) return ERRO_LAB;

  	GRAFO **p = &lab->vet[c1];
    (*p)->no = (GRAFO**)realloc((*p)->no,(sizeof(GRAFO*)*(*p)->liga)+1);
    
    //GRAFO ***aux;
    (*p)->no[(*p)->liga] = lab->vet[c2];

    (*p)->liga++;
    return SUCESS;
}

PILHA *criarpilha(){
	PILHA *novo= (PILHA*)calloc(1, sizeof(PILHA));
	return novo;
}

int empilhar(PILHA* pilha,int x){
	if(!pilha) return ERRO_PILHA;
	pilha->cap++;
    //puts("luya");
	pilha->vet = (int*)realloc(pilha->vet,sizeof(int)*pilha->cap);
    pilha->vet[pilha->cap] = x;
	return SUCESS;
}

int reempilhar(PILHA* pilha){
	if(!pilha) return ERRO_PILHA;
	int x = pilha->vet[pilha->cap];
	pilha->cap--;
	pilha->vet = (int*)realloc(pilha->vet,sizeof(int)*pilha->cap);
	return x;	
}


int imprimePilha(PILHA* p){
    if(!p) return ERRO_PILHA;
    int i;
    for(i=0;i<p->cap;i++)
        printf("%d ",p->vet[i]);

    
    return SUCESS;
}
int **processar(LAB *lab,int inicial){
	//if(!lab) return ERRO_LAB;
	PILHA *pi = criarpilha();
	int **vet = (int**)calloc(1,sizeof(int*));
	GRAFO **p = &lab->vet[inicial];
	GRAFO **aux;
	int flag,nCamara;
	int segPercorridos;
	
	//while(flag){
        //printf("%d sds\n",(*p)->pos);
		while((*p)->aberto == 1){
			empilhar(pi,(*p)->pos);
			p = &(*p)->no[(*p)->vistado];
		}
	//}
	imprimePilha(pi);

	return SUCESS;
}