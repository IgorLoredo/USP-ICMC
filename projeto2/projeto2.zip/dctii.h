#ifndef dctii
#define dctii

void dct(double*ino,double *out,int size); //comando dct II

#endif

