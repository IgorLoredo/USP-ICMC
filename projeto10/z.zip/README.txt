Arquivo zip gerado em: 13/11/2019 02:44:55 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: This is Esparsa!!!