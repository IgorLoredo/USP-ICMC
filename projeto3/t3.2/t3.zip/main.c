#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// captcha_01.pgm
/*struct pgm{
	//char *tipo;
	int l,c;
	char **matriz;
};
void entrada(FILE *p2, struct pgm *imagem){
	int i,j;
	fscanf(p2, "%d %d", &imagem->l,&imagem->c);
	printf("%d %d", imagem->l, imagem->c);
	//imagem->matriz = (int **)malloc(sizeof(int*)*imagem->l);
	for(i =0; i>imagem->l;i++)
		imagem->matriz[i] =  malloc(sizeof(int)*imagem->c);

	for(i =0; i>imagem->l;i++){
		for(j =0; j>imagem->c;j++){
			fscanf(p2,"%d",&imagem->matriz[i][j]);
		}
	} 
}*/

void printMatriz(int linha,int col,int **imagem){
	int i,j;
	for(j =0; j<col;j++){
		for(i =0; i<linha;i++){
			printf ("%d",imagem[j][i]);
		}
		printf("\n");
	}
}

int main(void) {
	char *tipo, *nomeARQ;
	int i,j;
	int tamLinhas, tamColunas, ampla; 
	//int **imagem;
	tipo = (char *)malloc(sizeof(char)*2);
	nomeARQ= (char *)malloc(sizeof(char)*20);
	scanf("%s", nomeARQ);
	FILE *img;
	//struct pgm *imagem;
	img = fopen(nomeARQ, "r");
	if(img  == NULL){
		printf("ERROR AO LER O ARQUIVO");
		exit(1);
	}
	fscanf(img, "%s", tipo);
	fscanf(img,"%d %d %d", &tamLinhas,&tamColunas,&ampla);

	int **imagem = (int **)malloc(sizeof(int *)*tamLinhas);
	for(i=0;i<tamLinhas;i++)
		imagem[i] = (int*)malloc(sizeof(int)*tamColunas); 

	for(i =0; i<tamLinhas;i++){
		for(j =0; j<tamColunas;j++){
			fscanf(img, "%d", &imagem[i][j]);
		}
	}
	printMatriz(tamLinhas,tamColunas,imagem);
	printf("%s\n%d %d", tipo, tamLinhas,tamColunas);



	/*fscanf(img, "\n%d %d", &imagem->l,&imagem->c);

	printf("%d %d", imagem->l, imagem->c);
	if(strcmp(tipo,"P2") == 0){
		//printf("deu certo\n");
		//entrada(img,imagem);
	} */
	//printMatriz(imagem);
	
	free(tipo);
	free(nomeARQ);
  return 0;
}