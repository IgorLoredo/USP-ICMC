#ifndef pgm
#define pgm

// funções que usei no codigo
void printMatriz(int ,int,int **);
void limpaZERO(int , int , int **);
int contMatriz(int ,int ,int **);
int indentificar(int ,int , int **);
void achar(int ,int ,int **, int*);
void contador(int ,int ,int ,int *, int *, int **);

#endif