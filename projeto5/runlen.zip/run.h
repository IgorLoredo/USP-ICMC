#ifndef run_h
#define run_h

void printMatriz(int **,int,int);
void runlen(int,int,int,char*);
void P2(int**,int,int,int);
void P8(int,int,int);

#endif 
 